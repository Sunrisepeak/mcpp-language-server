from pathlib import Path
import subprocess,json,time,hashlib,shutil
area=Path('.payload-cache/59-63-source-watch-and-zed');snap=json.loads((area/'source-after-session-test-fix.json').read_text());results=[]
for profile,bucket in [('dev','236c83cd76e7ed42'),('release','5d1fc926879f06ed')]:
 for p,digest in snap['files'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest,p+' changed during frozen build'
 name='build-workspace-'+profile;args=['taskset','-c','24-31','mcpp','build','--workspace','--profile',profile,'--jobs','4'];start=time.time();print(name+' START',flush=True)
 with (area/(name+'.log')).open('x') as out:r=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT)
 result={'profile':profile,'args':args,'exit':r.returncode,'wallSeconds':time.time()-start};results.append(result);(area/'workspace-builds.json').write_text(json.dumps({'results':results,'complete':len(results)==2,'passed':all(x['exit']==0 for x in results)},indent=2)+'\n');print(name+' EXIT '+str(r.returncode),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 frozen=area/('frozen-'+profile);frozen.mkdir(exist_ok=False);binaries={}
 for name in ['mcppls','mcppls-conformance','mcppls-mock-mcpp']:
  original=Path('target/x86_64-linux-gnu')/bucket/'bin'/name;assert original.is_file(),str(original);dest=frozen/name;shutil.copy2(original,dest);binaries[name]={'path':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'size':dest.stat().st_size}
 (area/('binaries-'+profile+'.json')).write_text(json.dumps({'profile':profile,'sourceKind':'frozen dirty snapshot','sourceSnapshot':'source-after-session-test-fix.json','baseCommit':snap['base'],'binaries':binaries},indent=2)+'\n');print('Frozen '+profile+' matching3binaries',flush=True)
