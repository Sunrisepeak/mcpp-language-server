from pathlib import Path
import subprocess,json,time,hashlib
area=Path('.payload-cache/59-63-source-watch-and-zed');snapshot=json.loads((area/'source-after-session-test-fix.json').read_text());results=[]
for profile,target in [('dev','test_session'),('release','test_scan'),('release','test_answer_routing'),('release','test_session')]:
 for p,digest in snapshot['files'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest,p+' changed during frozen validation'
 name=profile+'-'+target+'-fixed';args=['taskset','-c','24-31','mcpp','test',target,'--profile',profile];start=time.time();print(name+' START',flush=True)
 with (area/(name+'.log')).open('x') as out:r=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT)
 result={'name':name,'args':args,'exit':r.returncode,'wallSeconds':time.time()-start};results.append(result);(area/'focused-fixed-tests.json').write_text(json.dumps({'results':results,'expected':4,'complete':len(results)==4,'passed':all(x['exit']==0 for x in results),'unchangedProductDevChecks':'focused-tests.json firsttwoPASS; only test_session typecomparison amended'},indent=2)+'\n');print(name+' EXIT '+str(r.returncode),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
