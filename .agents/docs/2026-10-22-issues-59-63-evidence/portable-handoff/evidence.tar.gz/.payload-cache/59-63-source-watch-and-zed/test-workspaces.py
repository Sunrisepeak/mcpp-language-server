from pathlib import Path
import subprocess,json,time,os,hashlib
area=Path('.payload-cache/59-63-source-watch-and-zed');snap=json.loads((area/'source-after-session-test-fix.json').read_text());results=[]
for profile in ['dev','release']:
 for p,digest in snap['files'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest,p+' changed during frozen tests'
 args=['taskset','-c','24-31','mcpp','test','--workspace','--profile',profile];env=dict(os.environ,MCPPLS_CONFORMANCE=str((area/('frozen-'+profile)/'mcppls-conformance').resolve()));start=time.time();print('workspace-'+profile+' START',flush=True)
 with (area/('workspace-tests-'+profile+'.log')).open('x') as out:r=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
 results.append({'profile':profile,'args':args,'MCPPLS_CONFORMANCE':env['MCPPLS_CONFORMANCE'],'exit':r.returncode,'wallSeconds':time.time()-start});(area/'workspace-tests.json').write_text(json.dumps({'results':results,'complete':len(results)==2,'passed':all(x['exit']==0 for x in results)},indent=2)+'\n');print('workspace-'+profile+' EXIT '+str(r.returncode),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
