from pathlib import Path
import subprocess,json,time
area=Path('.payload-cache/59-63-source-watch-and-zed');results=[]
for profile in ['dev','release']:
 start=time.time();args=['taskset','-c','12-19','python3',str(area/'run-fixtures.py'),profile];print(profile+' 32fixtures START',flush=True)
 with (area/('fixtures-'+profile+'-run.log')).open('x') as out:r=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT)
 results.append({'profile':profile,'args':args,'exit':r.returncode,'wallSeconds':time.time()-start});(area/'fixture-runs.json').write_text(json.dumps({'results':results,'complete':len(results)==2,'passed':all(x['exit']==0 for x in results)},indent=2)+'\n');print(profile+' 32fixtures EXIT '+str(r.returncode),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
