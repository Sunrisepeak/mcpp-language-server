import concurrent.futures,json,os,pathlib,subprocess,sys
root=pathlib.Path.cwd();profile=sys.argv[1];area=root/'.payload-cache/59-63-source-watch-and-zed';binary=area/('frozen-'+profile);payload=root/'.payload-cache/59-63-release16/payload';out=area/('fixtures-'+profile);out.mkdir(exist_ok=False)
canonical=json.loads((root/'.payload-cache/59-63-status-transaction/fixtures-dev/summary.json').read_text());assert len(canonical)==31 and all(c['exitCode']==0 for c in canonical)
cases=[(row['fixture'].split('@')[0],row['fixture'],row['fixture'].endswith('@polling') or row['fixture']=='mcpp-polling-watch-inputs') for row in canonical]
assert all(name!='mcpp-target-windows-real' for _,name,_ in cases)
cases.append(('mcpp-watched-source-structure','mcpp-watched-source-structure',False))
env=dict(os.environ,CONFORMANCE_CLANGXX='/home/speak/.mcpp/registry/data/xpkgs/xim-x-llvm/22.1.8/bin/clang++')
def run(case):
 fixture,name,polling=case;command=[str(binary/'mcppls-conformance'),'run','--server',str(binary/'mcppls'),'--payload',str(payload),'--fixture',str(root/'conformance/fixtures'/fixture),'--timeout','60','--measure',str(out/(name+'.json'))]
 if polling:command.append('--no-dynamic-watch')
 if name=='mcpp-watched-source-structure':command+=['--workspace-dir',str(out/'watched-source-workspace'),'--cache-dir',str(out/'watched-source-cache'),'--verbose']
 with (out/(name+'.log')).open('x') as log:
  try:code=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600 if name=='mcpp-watched-source-structure' else 240).returncode
  except subprocess.TimeoutExpired:code=124
 print(name+': '+str(code),flush=True);return {'fixture':name,'exitCode':code,'command':command}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,cases))
(out/'summary.json').write_text(json.dumps({'profile':profile,'canonicalLinuxCases':31,'newRegressionCases':1,'nativeWindowsRealFixture':'platform-specific; nativeWindowsCI required, not attempted onLinux','results':results,'failed':sum(r['exitCode']!=0 for r in results)},indent=2)+'\n');sys.exit(any(r['exitCode'] for r in results))
