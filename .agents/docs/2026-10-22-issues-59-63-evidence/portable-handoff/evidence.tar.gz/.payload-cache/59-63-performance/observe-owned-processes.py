#!/usr/bin/env python3
"""Read-only, bounded Linux /proc observer for one explicitly selected process tree.

Only the JSONL output is written. No signals, payload reads, cache copies or fsync.
Polling can miss short-lived children; reparented children are retained only if seen
before reparenting. Counters are cumulative, not causal attribution. PSI is host-wide
and does not identify another workload. This observer itself has nonzero overhead.
Run affinity is deliberately left to external taskset. Python 3 standard library only.
"""

import argparse
import json
import os
import pathlib
import signal
import time


PROC = pathlib.Path('/proc')
STATUS = {'VmRSS', 'VmHWM', 'VmSwap', 'Threads', 'Cpus_allowed_list',
          'voluntary_ctxt_switches', 'nonvoluntary_ctxt_switches'}
stopping = False


def stop(_signum, _frame):
    global stopping
    stopping = True


def process_stat(pid):
    text = (PROC / str(pid) / 'stat').read_text()
    opening, closing = text.find('('), text.rfind(')')
    if opening < 0 or closing <= opening:
        raise ValueError('invalid /proc stat')
    fields = text[closing + 2:].split()
    def optional_counter(index):
        return int(fields[index]) if len(fields) > index else None

    return {'pid': pid, 'comm': text[opening + 1:closing], 'state': fields[0],
            'ppid': int(fields[1]), 'userTicks': int(fields[11]),
            'minorFaults': optional_counter(7), 'majorFaults': optional_counter(9),
            'delayacctBlockIoTicks': optional_counter(39),
            'systemTicks': int(fields[12]), 'threads': int(fields[17]),
            'startTicks': int(fields[19]), 'virtualBytes': int(fields[20]),
            'rssPages': int(fields[21])}


def children(pid):
    # A process may create children from a non-main thread. Restrict discovery to
    # the already-owned process, rather than scanning every process on the host.
    found = set()
    for task in (PROC / str(pid) / 'task').iterdir():
        try:
            found.update(int(x) for x in (task / 'children').read_text().split())
        except (OSError, ValueError):
            pass
    return found


def counters(pid):
    base = PROC / str(pid)
    result = {}
    for filename in ('io', 'status', 'schedstat'):
        try:
            text = (base / filename).read_text()
            if filename == 'schedstat':
                values = [int(x) for x in text.split()]
                result['schedstat'] = dict(zip(('runtimeNs', 'runqueueWaitNs', 'timeslices'), values))
            else:
                values = dict(line.split(':', 1) for line in text.splitlines() if ':' in line)
                if filename == 'status':
                    result['status'] = {k: v.strip() for k, v in values.items() if k in STATUS}
                else:
                    result['io'] = {k: int(v) for k, v in values.items()}
        except (OSError, ValueError):
            result[filename] = None
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-pid', required=True, type=int)
    parser.add_argument('--out', required=True, type=pathlib.Path)
    parser.add_argument('--duration', type=float, default=3600,
                        help='maximum seconds, default 3600; must be positive and <=86400')
    args = parser.parse_args()
    if args.root_pid <= 0 or not 0 < args.duration <= 86400:
        parser.error('positive root PID and finite duration in (0,86400] required')
    try:
        root = process_stat(args.root_pid)
    except (OSError, ValueError, IndexError) as error:
        parser.error(f'cannot read root: {error}')
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, stop)
    started = time.monotonic()
    known = {args.root_pid: root['startTicks']}
    announced = set()
    next_sample, next_psi = started, started
    with args.out.open('a', buffering=1) as out:
        def emit(kind, **data):
            now = time.monotonic()
            out.write(json.dumps({'kind': kind, 'monotonic': now,
                                  'elapsed': now - started, 'epoch': time.time(), **data},
                                 separators=(',', ':')) + '\n')

        emit('start', rootPid=args.root_pid, rootStartTicks=root['startTicks'],
             durationLimit=args.duration, clockTicks=os.sysconf('SC_CLK_TCK'),
             pageBytes=os.sysconf('SC_PAGE_SIZE'), observerPid=os.getpid(),
             limits='polling misses transient children; cumulative counters; host-wide PSI; no causal attribution')
        reason = 'duration-limit'
        while not stopping and time.monotonic() - started < args.duration:
            pending = list(known)
            visited, live, samples = set(), {}, []
            errors = 0
            while pending and len(visited) < 4096:
                pid = pending.pop()
                if pid in visited or pid == os.getpid():
                    continue
                visited.add(pid)
                try:
                    stat = process_stat(pid)
                    identity = (pid, stat['startTicks'])
                    if pid in known and known[pid] != stat['startTicks']:
                        continue  # PID reuse never transfers ownership.
                    if identity not in announced:
                        emit('seen', **stat)
                        announced.add(identity)
                    samples.append({**stat, **counters(pid)})
                    if stat['state'] != 'Z':
                        live[pid] = stat['startTicks']
                        pending.extend(children(pid) - visited)
                    elif pid not in known:
                        emit('gone', pid=pid, startTicks=stat['startTicks'],
                             note='first observed as zombie; exit status unknown')
                except (OSError, ValueError, IndexError):
                    errors += 1
            for pid, birth in known.items():
                if pid not in live:
                    emit('gone', pid=pid, startTicks=birth,
                         note='no longer readable, exited/zombie, or PID reused; exit status unknown')
            known = live
            emit('sample', processes=samples, readErrors=errors,
                 discoveryTruncated=bool(pending))
            now = time.monotonic()
            if now >= next_psi:
                psi = {}
                for resource in ('cpu', 'io', 'memory'):
                    try:
                        psi[resource] = (PROC / 'pressure' / resource).read_text().strip()
                    except OSError:
                        psi[resource] = None
                emit('host-psi', pressure=psi)
                next_psi = now + 5
            if not known:
                reason = 'owned-tree-ended'
                break
            next_sample += 1
            # Avoid catch-up bursts after a slow pass; duration remains bounded.
            if next_sample < time.monotonic():
                next_sample = time.monotonic()
            remaining = min(next_sample, started + args.duration) - time.monotonic()
            if remaining > 0:
                time.sleep(remaining)
        emit('end', reason='signal' if stopping else reason, remainingPids=sorted(known))


if __name__ == '__main__':
    main()
