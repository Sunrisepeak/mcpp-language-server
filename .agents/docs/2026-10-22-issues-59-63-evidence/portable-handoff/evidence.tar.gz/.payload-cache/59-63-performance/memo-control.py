import pathlib,subprocess,json,time,shutil,threading,os
root=pathlib.Path('.payload-cache/59-63-performance').resolve();original=next((root/'xlings-staged-cache').rglob('module-memos.json'));target=root/'memo-only';target.mkdir(exist_ok=True);shutil.copyfile(original,target/'module-memos.json')
engine=pathlib.Path('.payload-cache/59-63-release16/payload/clangd/bin/clangd').resolve();log=(root/'memo-only.log').open('wb');proc=subprocess.Popen(['taskset','-c','0-1',str(engine),'--module-memo-dir='+str(target),'--log=verbose','--background-index=false','-j=3'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log)
def send(value):
 b=json.dumps(value).encode();proc.stdin.write(b'Content-Length: '+str(len(b)).encode()+b'\r\n\r\n'+b);proc.stdin.flush()
def read():
 with (root/'memo-only-lsp.log').open('wb') as out:
  while True:
   data=proc.stdout.read(4096)
   if not data:break
   out.write(data);out.flush()
threading.Thread(target=read,daemon=True).start();send({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'processId':os.getpid(),'rootUri':None,'capabilities':{}}});send({'jsonrpc':'2.0','method':'initialized','params':{}});start=time.monotonic()
(root/'memo-only-pid').write_text(str(proc.pid))
with (root/'memo-only-smaps.jsonl').open('w') as out:
 while time.monotonic()-start<180 and proc.poll() is None:
  p=pathlib.Path('/proc')/str(proc.pid)
  try:out.write(json.dumps({'time':time.time(),'elapsed':time.monotonic()-start,'pid':proc.pid,'stat':(p/'stat').read_text(),'smaps':(p/'smaps_rollup').read_text()})+'\n');out.flush()
  except OSError:pass
  time.sleep(.2)
 send({'jsonrpc':'2.0','id':2,'method':'shutdown','params':None});time.sleep(.3);send({'jsonrpc':'2.0','method':'exit','params':None})
try:proc.wait(timeout=10)
except subprocess.TimeoutExpired:proc.terminate();proc.wait(timeout=5)
log.close()
