"""One isolated original mcpp four-stage diagnostic; original file sink, explicit diagnostic runner provenance."""
import pathlib,json,hashlib,os,subprocess,sys,time,stat,signal,shutil
REPO=pathlib.Path.cwd(); AREA=pathlib.Path(__file__).resolve().parent
STATE=AREA/'state'; WORK=STATE/'workspace'; CACHE=STATE/'cache'; BASELINE=AREA/'baseline-cache'
BIN=REPO/'.payload-cache/59-63-status-transaction/frozen-release'
OBSERVER=REPO/'.payload-cache/59-63-performance/observe-owned-processes.py'
FIXTURE=REPO/'.payload-cache/59-63-performance/mcpp-staged-fixture'
PAYLOAD=REPO/'.payload-cache/59-63-release16/payload'
SERVER_SHA='34924e25450d1c84feac8f616826a8c0060a3c89ccc92ab79800304c9fd0024c'
RUNNER=None;RUNNER_PROVENANCE=None;EXPECTED={};RUN_ENV=None
PRODUCER_PREFIX=pathlib.Path('/home/speak/.xlings/data/xpkgs/xim-x-mcpp/2026.9.30.2')

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()

def write(p,j):p.write_text(json.dumps(j,indent=2)+'\n')

def launch_observer(pid,out):
 log=open(out.with_suffix('.stderr.log'),'w')
 p=subprocess.Popen(['taskset','-c','9',sys.executable,str(OBSERVER),'--root-pid',str(pid),'--out',str(out),'--duration','1800'],stdout=log,stderr=log)
 return p,log

def check_space(stage_dir):
 free=os.statvfs(stage_dir).f_bavail*os.statvfs(stage_dir).f_frsize
 row={'epoch':time.time(),'monotonic':time.monotonic(),'freeBytes':free,'stopBelowBytes':1024**3}
 with (stage_dir/'free-space.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 shared=pathlib.Path(__file__).resolve().parent/'space-abort.json'
 if free<1024**3:
  incident={**row,'project':AREA.name,'stage':stage_dir.name,'overall':'FAIL','action':'stop only this diagnostic exact owned tree; preserve evidence; no retry'}
  try:
   with shared.open('x') as f:f.write(json.dumps(incident,indent=2)+'\n')
  except FileExistsError:pass
 if shared.exists():
  write(stage_dir/'low-space.json',{'overall':'FAIL','localSample':row,'sharedIncident':str(shared),'retry':False})
  raise RuntimeError('LOW SPACE: diagnostic storage failure; exact owned cleanup, evidence preserved')
 return free

def wait_observer(p,handle,out):
 deadline=time.monotonic()+1810
 while True:
  check_space(out.parent)
  try:code=p.wait(timeout=5);break
  except subprocess.TimeoutExpired:
   if time.monotonic()<deadline:continue
   p.terminate()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.kill();p.wait()
   raise RuntimeError('observer exceeded its declared finite duration: '+str(out))
 handle.close()
 assert code==0,('observer failed',out,code)
 end=json.loads(out.read_text().splitlines()[-1]);assert end['kind']=='end' and end['reason']=='owned-tree-ended' and not end['remainingPids'],('owned tree not confirmed ended',out,end)

def extend_owned(known,root):
 # Refresh only this known tree, including children created since the observer's last1s poll.
 if root and root.poll() is None:
  try:
   raw=(pathlib.Path('/proc')/str(root.pid)/'stat').read_text();f=raw[raw.rfind(')')+2:].split();known[root.pid]=int(f[19])
  except (OSError,ValueError,IndexError):pass
 pending=list(known.items());seen=set()
 while pending:
  pid,birth=pending.pop()
  if pid in seen:continue
  seen.add(pid)
  try:
   raw=(pathlib.Path('/proc')/str(pid)/'stat').read_text();f=raw[raw.rfind(')')+2:].split()
   if int(f[19])!=birth:continue
   for child_file in (pathlib.Path('/proc')/str(pid)/'task').glob('*/children'):
    for value in child_file.read_text().split():
     child=int(value)
     try:
      raw=(pathlib.Path('/proc')/str(child)/'stat').read_text();cf=raw[raw.rfind(')')+2:].split()
      if int(cf[1])!=pid:continue
      cb=int(cf[19]);known[child]=cb;pending.append((child,cb))
     except (OSError,ValueError,IndexError):pass
  except (OSError,ValueError,IndexError):pass

def preserve_logs(stage_dir):
 # Only after runner and observed descendants ended; never walk PCM/cache payloads.
 started=time.monotonic();source=CACHE/'logs';destination=stage_dir/'server-logs';destination.mkdir()
 entries=[]
 if source.is_dir():
  for path in sorted(source.rglob('*')):
   if path.is_symlink():
    entries.append({'path':str(path.relative_to(source)),'symlink':os.readlink(path),'copied':False});continue
   if not path.is_file():continue
   relative=path.relative_to(source);target=destination/relative;target.parent.mkdir(parents=True,exist_ok=True)
   digest=hashlib.sha256();size=0
   with path.open('rb') as src,target.open('xb') as dst:
    for block in iter(lambda:src.read(128*1024),b''):dst.write(block);digest.update(block);size+=len(block)
   entries.append({'path':str(relative),'bytes':size,'sha256':digest.hexdigest()})
 result={'copiedAfterObservedTreeEnd':True,'source':str(source),'files':entries,'seconds':time.monotonic()-started,
         'scope':'retained log files only; complete emitted server stderr in direct runner.log; no PCM reads, restore, cache mutation or analysis'}
 write(stage_dir/'server-log-archive.json',result);return result


def run_stage(label,stage):
 out=AREA/label;out.mkdir();check_space(out)
 actual={'mcppls':sha(BIN/'mcppls'),'mcppls-conformance':sha(RUNNER)};assert actual==EXPECTED,'frozen server/diagnostic runner bytes changed'
 write(out/'binaries.json',actual)
 args=['taskset','-c',CPUS,str(RUNNER),'run','--server',str(BIN/'mcppls'),'--payload',str(PAYLOAD),'--fixture',str(FIXTURE),'--workspace-dir',str(WORK),'--cache-dir',str(CACHE),'--stage',stage,'--timeout','900','--measure',str(out/'measure.json'),'--verbose']
 if stage in ('warm','edits','long'):args.append('--expect-warm')
 runner=None;observer=None
 try:
  begin=time.time();write(out/'invocation.json',{'epoch':begin,'args':args,'diagnosticOnly':True,'notNineStageAcceptance':True,'productServerSource':'1341938594ba494e686489c3696f2b740f67684d','diagnosticRunnerProvenance':RUNNER_PROVENANCE})
  print(label,'START',flush=True)
  with (out/'runner.log').open('w') as log:
   runner=subprocess.Popen(args,stdout=log,stderr=log,env=RUN_ENV)
   observer=launch_observer(runner.pid,out/'processes.jsonl')
   while True:
    check_space(out)
    try:code=runner.wait(timeout=5);break
    except subprocess.TimeoutExpired:pass
  wait_observer(*observer,out/'processes.jsonl')
  check_space(out);archive=preserve_logs(out);check_space(out)
  result={'exit':code,'epochEnd':time.time(),'wallSeconds':time.time()-begin,'archiveSeconds':archive['seconds'],'diagnosticOnly':True}
  write(out/'exit.json',result);print(label,'EXIT',code,flush=True)
  return result

 except BaseException as error:
  # Only this diagnostic's exact observed PID/start-time identities are eligible.
  known={}
  for name in ['processes.jsonl']:
   path=out/name
   if path.exists():
    for line in path.read_text().splitlines():
     try:
      item=json.loads(line)
      records=item.get('processes',[]) if item.get('kind')=='sample' else [item] if item.get('kind')=='seen' else []
      for record in records:known[int(record['pid'])]=int(record['startTicks'])
     except (ValueError,KeyError):pass
  for sig in [signal.SIGTERM,signal.SIGKILL]:
   extend_owned(known,runner)
   for pid,birth in known.items():
    try:
     raw=(pathlib.Path('/proc')/str(pid)/'stat').read_text();fields=raw[raw.rfind(')')+2:].split()
     if int(fields[19])==birth:os.kill(pid,sig)
    except (OSError,ValueError,IndexError):pass
   for proc in [runner,observer[0] if observer else None]:
    if proc and proc.poll() is None:
     try:proc.send_signal(sig)
     except ProcessLookupError:pass
   if sig==signal.SIGTERM:time.sleep(1)
  for proc in [runner,observer[0] if observer else None]:
   if proc:
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:pass
  write(out/'orchestration-failure.json',{'overall':'FAIL','reason':str(error),'exactKnownPids':known,'cleanup':'only this diagnostic known tree with verified PID birth identities and direct child handles; no retry'})
  raise

def main():
 global AREA,WORK,CACHE,FIXTURE,CPUS,EXPECTED,RUNNER,RUNNER_PROVENANCE,RUN_ENV
 assert len(sys.argv)==1,'fixed diagnostic takes no project or stage selection'
 project='mcpp';AREA=AREA/project;AREA.mkdir(exist_ok=True)
 marker=AREA/'started.json'
 assert not marker.exists(),'one complete attempt per project; no stage reroll'
 assert not (AREA/'interrupted.json').exists(),'prior interrupted execution requires explicit review and evidence preservation; no automatic retry'
 WORK=AREA/'workspace';assert not WORK.exists() and not (AREA/'cache-a').exists() and not (AREA/'cache-b').exists(),'fresh independent lineage required'
 CPUS='4-5'
 FIXTURE=REPO/'.payload-cache/59-63-performance'/(project+'-staged-fixture')
 metadata=json.loads((REPO/'.payload-cache/59-63-status-transaction/binaries-release.json').read_text())
 assert metadata['source']=='1341938594ba494e686489c3696f2b740f67684d' and metadata['profile']=='release','final root release freeze required'
 assert metadata['binaries']['mcppls']['sha256']==SERVER_SHA and sha(BIN/'mcppls')==SERVER_SHA,'frozen134 product server changed'
 plan=json.loads((pathlib.Path(__file__).resolve().parent/'diagnostic-plan.json').read_text())
 dependency=plan['runnerDependency'];assert dependency['ready'] is True,'WAIT: root must supply exact diagnostic runner path/SHA/provenance before any workload'
 assert dependency['profile']=='release' and dependency['path'] and dependency['sha256'],'incomplete diagnostic runner binding'
 RUNNER=pathlib.Path(dependency['path']);assert RUNNER.is_absolute() and RUNNER.is_file() and sha(RUNNER)==dependency['sha256'],'diagnostic runner bytes differ'
 RUNNER_PROVENANCE=dependency['provenance'];assert RUNNER_PROVENANCE['kind'] in ('committed','dirty-patch'),'explicit runner source kind required'
 if RUNNER_PROVENANCE['kind']=='committed':assert len(RUNNER_PROVENANCE['sourceCommit'])==40,'runner source commit required'
 else:
  assert len(RUNNER_PROVENANCE['baseCommit'])==40 and sha(pathlib.Path(RUNNER_PROVENANCE['patchPath']))==RUNNER_PROVENANCE['patchSha256'],'runner dirty patch identity required'
 EXPECTED={'mcppls':SERVER_SHA,'mcppls-conformance':dependency['sha256']}
 sample=os.statvfs(AREA);free=sample.f_bavail*sample.f_frsize
 preflight={'epoch':time.time(),'actualFreeBytes':free,'requiredBytes':4*1024**3,'storageGuardMet':free>=4*1024**3,'status':'storage-precheck-met-awaiting-marker' if free>=4*1024**3 else 'infrastructure-preflight-refused','productAttemptStarted':False,'project':project,'source':'1341938594ba494e686489c3696f2b740f67684d','stageCount':0}
 write(AREA/'preflight.json',preflight)
 assert free>=4*1024**3,f'4GiB diagnostic storage reservation not met; no start; actualFreeBytes={free}; requiredBytes={4*1024**3}'
 assert sha(FIXTURE/'scenario.json')==plan['allOriginalThresholdsAndInputs'][project]['sha256'],'fixture changed since registration'
 assert plan['binaries']==EXPECTED and sha(pathlib.Path(__file__).resolve())==plan['scriptSHA256'],'registered script/product mismatch'
 assert sha(OBSERVER)==plan['observer']['sha256'],'observer changed since registration'
 assert not (pathlib.Path(__file__).resolve().parent/'space-abort.json').exists(),'shared low-space failure already recorded; no reroll'
 # Pin fixture.prepare's bare mcpp as well as the original explicit server --mcpp.
 RUN_ENV=os.environ.copy();RUN_ENV['PATH']=str(PRODUCER_PREFIX/'bin')+os.pathsep+RUN_ENV.get('PATH','');RUN_ENV['XLINGS_NON_INTERACTIVE']='1'
 executable=shutil.which('mcpp',path=RUN_ENV['PATH'])
 assert executable and pathlib.Path(executable)==PRODUCER_PREFIX/'bin/mcpp','prepare producer resolution differs from fixed prefix'
 probe=subprocess.run([executable,'--version'],env=RUN_ENV,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=15,check=True)
 version=probe.stdout.strip();assert '2026.9.30.2' in version,'prepare producer version differs from pin'
 producer={'prefix':str(PRODUCER_PREFIX),'pathEntry':str(PRODUCER_PREFIX/'bin'),'executable':executable,'resolvedExecutable':str(pathlib.Path(executable).resolve()),'version':version,'versionCommand':[executable,'--version'],'XLINGS_NON_INTERACTIVE':'1','scope':'same explicit environment inherited by runner, fixture.prepare and server; no full environment dump'}
 assert plan['producerEnvironment']['prefix']==str(PRODUCER_PREFIX),'registered producer prefix differs'
 write(AREA/'producer-preflight.json',producer)
 preflight['producer']=producer;write(AREA/'preflight.json',preflight)
 sequence=['cold','warm','edits','faults']
 with marker.open('x') as f:f.write(json.dumps({'source':'1341938594ba494e686489c3696f2b740f67684d','profile':'release','epoch':time.time(),'project':project,'sequence':sequence,'binaries':EXPECTED,'oneAttempt':True,'diagnosticOnly':True,'notNineStageAcceptance':True,'originalFailuresPreserved':True,'diagnosticRunnerProvenance':RUNNER_PROVENANCE},indent=2)+'\n')
 results={}
 for stage in sequence:
  CACHE=AREA/('cache-b' if stage=='faults' else 'cache-a')
  results[stage]=run_stage(stage,stage)
  write(AREA/'progress.json',results)
 write(AREA/'completed.json',{'results':results,'overall':'PASS' if all(r['exit']==0 for r in results.values()) else 'FAIL','oneAttempt':True,'diagnosticOnly':True,'notNineStageAcceptance':True,'originalFailuresPreserved':True,'diagnosticRunnerProvenance':RUNNER_PROVENANCE})

if __name__=='__main__':
 try:main()
 except BaseException as e:
  destination=AREA/'interrupted.json'
  if destination.exists():destination=AREA/('launch-refusal-'+str(time.time_ns())+'.json')
  write(destination,{'epoch':time.time(),'type':type(e).__name__,'message':str(e),'overall':'FAIL','retry':False});raise
