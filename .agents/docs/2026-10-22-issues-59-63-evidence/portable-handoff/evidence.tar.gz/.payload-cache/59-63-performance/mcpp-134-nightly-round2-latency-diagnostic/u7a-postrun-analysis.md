U7a 本轮真实失败：8个 importer 的诊断重发耗时107.246649735s，原门槛33s不变。唯一迟到文件是 `src/config.cppm`；其他7个在保存后0.822–5.605s内由clangd重发。

| UTC（2026-10-22） | 证据 |
|---|---|
| 10:01:27.537 | config首次AST构建，U7a打开/settle阶段 |
| 10:01:28.649 | clangd打印Build AST crash context，文件config，栈含musable/realloc |
| 10:01:30.566 | mcppls将config隔离 |
| 10:01:30.762 | clangd因exit重启，仍在保存前 |
| 10:01:44.331 | clangd收到log.cppm didSave；对应客户端保存测量起点附近 |
| 10:01:44.729 | mcpp.log BMI构建完成 |
| 10:01:46.619 | mcpp.config BMI构建完成 |
| 10:01:48.597 | 首importer probe诊断已清除 |
| 10:01:49.936 | 除config外7个importer均已重发 |
| 10:02:02.077 | 此窗口最后一条Built module，mcpp.pack.pipeline |
| 10:03:30.782 | config隔离120.216s后handed back |
| 10:03:30.829–10:03:31.559 | config新AST构建/索引，约0.730s |
| 10:03:31.560 | config终于publishDiagnostics；日志save→pub107.229s |

`guard.cppm::FIRST_TERM=2min`、`Quarantine::put/due`及driver timer与120秒时序一致。crash隔离传入moduleFailed=false，而sources_changed只释放moduleFailed隔离；log函数体变更没有改变config自身结构/命令，也没有现有“成功新依赖闭包→释放crash隔离”规则。因此不是107秒AST构建，也没有保存窗口producer/model重载日志。42条Built module截至10:02:02.077，期间108次engine completion回复，交互p95 .250s/max .642s；不能把等待说成engine整体停顿。

U7a的before报告在setup/settle之后、save之前，因此该预保存crash不进入restarts增量，measure的0不矛盾。前序是U5→U6→U16→U7a；不能误说crash发生在U6窗口。日志UTC毫秒精度且有转发延迟，107.229只作客户端steady-clock107.24665的交叉证据，不宣称两个时钟相同。

不能通过缩短隔离期或无条件handback消除失败。可检验的下一步是：为crash verdict记录实际依赖闭包身份；仅在相关依赖成功产出不同有效闭包且仍符合磁盘安全约束后，允许一次有界重试，并测试同闭包不复活、无关保存不复活、构建失败不复活、重复崩溃仍退避。当前日志证明mcpp.log/mcpp.config确实重建，但尚不能证明原crash条件已消失；这不是已证明可安全实施的修复。

完整已打印stack/context保存在u7a-crash-stack-context.txt；细节、原日志行号、8文件发布时间及边界见u7a-postrun-analysis.json。局部registry的UP-20指manifest.types扇出保存崩溃，本次config在保存前打开时崩溃，未建立相同签名。底层crash原因仍UNASSIGNED。本轮U5/U6通过不能解释或覆盖历史8.264/6.38秒失败。
