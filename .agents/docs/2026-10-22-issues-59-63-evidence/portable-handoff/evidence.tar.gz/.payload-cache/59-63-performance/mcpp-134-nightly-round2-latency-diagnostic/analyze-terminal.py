"""Read only after all four stages terminate; never scan raw logs, workspace or PCM.
Gate failures are results, not analysis errors. This diagnostic cannot prove a repair or assign cause.
"""
import pathlib,json,hashlib,math,time,os
AREA=pathlib.Path(__file__).resolve().parent
REPO=AREA.parents[2]
SOURCE='1341938594ba494e686489c3696f2b740f67684d'
SEQUENCE=['cold','warm','edits','faults']
MINUTE_NS=60_000_000_000
PLAN_SHA='f7bbfd17ae658fcacc37d9c967796b2a75b580a774568ac1cffdb3e90475e9e6'
RUN_SHA='077e293b935a280860952059d77d3805bdea647846618402ffe68eae188bc85a'
SERVER_SHA='34924e25450d1c84feac8f616826a8c0060a3c89ccc92ab79800304c9fd0024c'
RUNNER_SHA='7e6ebe108ccc5ff16387ed89d837a8dfb886159ae18091f05dc30d99fd238cda'
OBSERVER_SHA='8410c71b3dddfa42d96ba805012c850569952b0597a56022f3789a4fda09071a'

def require(value,message):
    if not value:raise RuntimeError(message)

def read(path):return json.loads(path.read_text())

def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()

def close_number(left,right):
    return isinstance(left,(int,float)) and math.isfinite(left) and abs(left-right)<=1e-7

def stats(values):
    values=sorted(values)
    def quantile(fraction):return values[min(len(values),max(1,math.ceil(fraction*len(values))))-1] if values else 0.0
    return {'n':len(values),'p50':quantile(.5),'p95':quantile(.95),'max':values[-1] if values else 0.0}

def completion_evidence(measure):
    trace=measure['completionTrace'];entries=trace['entries'];total=trace['total']
    require(trace['origin']=='typing-start' and trace['population']=='original-completion-statistics','wrong trace population')
    require(trace['limit']==256 and len(entries)==min(total,256) and trace['dropped']==total-len(entries),'trace truncation accounting differs')
    require(total==measure['completions'],'trace population differs from original completions')
    ids=set();previous_sent=None
    def validate(entry):
        sent=entry['sentNanoseconds'];answered=entry['answeredNanoseconds'];elapsed=entry['elapsedNanoseconds']
        require(isinstance(sent,int) and isinstance(entry['id'],int),'noninteger request timestamp/id')
        require(isinstance(entry['error'],bool),'missing original error flag')
        if answered is None:require(elapsed is None and entry['elapsedSeconds'] is None,'unanswered request has latency')
        else:
            require(isinstance(answered,int) and answered>=sent and elapsed==answered-sent,'request timestamp arithmetic differs')
            require(close_number(entry['elapsedSeconds'],elapsed/1e9),'request ns/seconds disagree')
    for index,entry in enumerate(entries):
        validate(entry);require(entry['index']==index and entry['id'] not in ids,'request prefix ordering/identity differs');ids.add(entry['id'])
        require(previous_sent is None or entry['sentNanoseconds']>=previous_sent,'send chronology differs');previous_sent=entry['sentNanoseconds']
    for key in ('slowestSuccessful','slowestAnswered'):
        entry=trace[key]
        if entry is not None:
            validate(entry);require(entry['answeredNanoseconds'] is not None and 0<=entry['index']<total,'invalid slowest support')
            if key=='slowestSuccessful':require(not entry['error'],'slowest successful is an error')
            if entry['index']<len(entries):require(entry==entries[entry['index']],'slowest support differs from original prefix')
    complete=trace['dropped']==0
    successful=[entry for entry in entries if entry['answeredNanoseconds'] is not None and not entry['error']]
    answered=[entry for entry in entries if entry['answeredNanoseconds'] is not None]
    recomputed=stats([entry['elapsedSeconds'] for entry in successful]) if complete else None
    if complete:
        require(recomputed['n']==measure['answered'],'successful request population differs')
        for key,value in recomputed.items():require(close_number(measure['completion'][key],value),'original completion statistic differs: '+key)
        for key,population in [('slowestSuccessful',successful),('slowestAnswered',answered)]:
            expected=max(population,key=lambda item:item['elapsedNanoseconds']) if population else None
            require(trace[key]==expected,'slowest support differs: '+key)
    slowest=trace['slowestSuccessful']
    require(close_number(measure['completion']['max'],slowest['elapsedSeconds'] if slowest else 0.0),'successful max not supported')
    return {'traceField':'completionTrace','completePopulation':complete,'total':total,'retained':len(entries),'dropped':trace['dropped'],
            'originalStatistics':measure['completion'],'recomputedStatistics':recomputed,'statisticsRecomputedExactly':complete,
            'truncationBoundary':'If dropped>0, prefix cannot establish full p50/p95; separate slowestSuccessful still supports full original max.',
            'slowestSuccessful':slowest,'slowestAnswered':trace['slowestAnswered'],
            'slowestSuccessfulPrefixRequests':sorted(successful,key=lambda item:item['elapsedNanoseconds'],reverse=True)[:10],
            'allRetainedRequests':entries,'clientTimeouts':measure['clientTimeouts'],'serverTimeouts':measure['serverTimeouts'],'errors':measure['errors']}

def server_evidence(measure):
    evidence=measure['serverCompletionEvidence'];slow=evidence['slowRequests'];events=slow['eventsAfter']
    before=slow['totalBefore'];after=slow['totalAfter']
    comparable=before is not None and after is not None and after>=before
    added=after-before if comparable else None
    require(slow['added']==added,'slow journal counter arithmetic differs')
    available=events is not None
    if available:
        require(isinstance(events,list) and len(events)<=256,'slow journal trace limit differs')
        require(slow['afterRecentCount']-len(events)==slow['droppedByTraceLimit'],'slow journal truncation arithmetic differs')
    known=comparable and available and slow['afterRecentCount']<=after
    retained=min(added,len(events)) if known else None
    require(slow['newRetained']==retained and slow['newNotRetained']==(added-retained if known else None),'slow journal coverage arithmetic differs')
    newevents=events[-retained:] if retained else []
    left=evidence['requestsBefore'];right=evidence['requestsAfter'];delta={}
    if isinstance(left,dict) and isinstance(right,dict):
        for key in ('count','empty','errors','cancelled','engineAnswered'):
            if isinstance(left.get(key),(int,float)) and isinstance(right.get(key),(int,float)):delta[key]=right[key]-left[key]
    return {'before':left,'after':right,'counterDeltas':delta,'scope':evidence['statisticsScope'],
            'slowJournal':slow,'coverageKnown':known,'newSlowEventsAllMethods':newevents,
            'newCompletionSlowEvents':[event for event in newevents if event.get('method')=='textDocument/completion'],
            'boundary':'Cumulative/recent distributions are not per-check percentiles. Slow-event counters cover all methods; events have no request ID, so time proximity does not prove individual matching. Missing/rolled events remain missing.'}


def trace_evidence(measure):
    """Recompute counted changes and the earliest maximum strict<60s window from compact evidence."""
    trace=measure['stateTransitionTrace'];require(isinstance(trace,list),'missing transition array')
    previous='';last_time=-1;last_sample=-1;counted=[];restart_boundaries=0;initials=0
    for index,entry in enumerate(trace):
        at=entry['sinceStartNanoseconds'];sample=entry['sampleIndex']
        require(isinstance(at,int) and at>=last_time and isinstance(sample,int) and sample>last_sample,'unordered transition trace')
        require(sample<measure['stateTransitionStatusSamples'],'transition sample outside analyzed range')
        require(close_number(entry['seconds'],at/1e9),'transition seconds/ns disagree')
        require(entry['seconds']<=measure['stateTransitionObservedThroughSeconds']+1e-7,'transition after observation cutoff')
        require(entry['from']==(previous if previous else None),'transition source/reset mismatch')
        require(isinstance(entry['done'],int) and isinstance(entry['total'],int) and isinstance(entry['issues'],list),'missing compact preparation context')
        require(all(isinstance(code,str) for code in entry['issues']),'issue trace contains non-code data')
        kind=entry['kind'];target=entry['to']
        if kind=='restart':
            require(target=='restart' and entry['counted'] is False,'restart counted as a change')
            previous='';restart_boundaries+=1
        elif kind=='initial':
            require(not previous and target!='restart' and entry['counted'] is False,'initial state counted as a change')
            previous=target;initials+=1
        else:
            require(kind=='change' and previous and target!=previous and target!='restart' and entry['counted'] is True,'invalid counted transition')
            counted.append(index);previous=target
        last_time=at;last_sample=sample
    require(len(counted)==measure['stateChanges'],'transition count differs from original metric')
    support=[]
    for offset,index in enumerate(counted):
        start=trace[index]['sinceStartNanoseconds'];candidate=[]
        for other in counted[offset:]:
            if trace[other]['sinceStartNanoseconds']-start>=MINUTE_NS:break
            candidate.append(other)
        if len(candidate)>len(support):support=candidate
    require(len(support)==measure['busiestMinuteChanges'],'recomputed busiest count differs')
    window=measure['busiestMinuteWindow']
    if not support:require(window is None,'zero changes require null busiest window')
    else:
        start=trace[support[0]]['sinceStartNanoseconds'];end=start+MINUTE_NS
        require(window['traceIndices']==support and window['count']==len(support),'busiest supporting indices differ')
        require(window['startNanoseconds']==start and window['endNanosecondsExclusive']==end,'strict window bounds differ')
        require(close_number(window['startSeconds'],start/1e9) and close_number(window['endSecondsExclusive'],end/1e9),'window seconds/ns disagree')
        require(close_number(window['lastChangeSeconds'],trace[support[-1]]['seconds']),'last supporting timestamp differs')
    return {'stateChanges':measure['stateChanges'],'busiestMinuteChanges':measure['busiestMinuteChanges'],
            'traceEntries':len(trace),'initialBoundaries':initials,'restartBoundaries':restart_boundaries,
            'recomputedExactly':True,'strictWindowSeconds':60,'window':window,
            'supportingTrace':[ {key:trace[index][key] for key in ('seconds','from','to','done','total','issues')} for index in support ],
            'errorStates':measure['errorStates'],'clangdRestarts':measure['clangdRestarts'],
            'rawNodeGapSeconds':measure['longestStallSeconds'],'actualEngineInactivitySeconds':measure['longestEngineInactivitySeconds'],
            'preparationStalledSamples':measure['preparationStalledSamples']}

def observer_evidence(path,identities,observers):
    last=None;start=None;records=0
    with path.open() as stream:
        for line in stream:
            if not line.strip():continue
            row=json.loads(line);last=row;records+=1
            if row.get('kind')=='start':
                require(start is None,'duplicate observer start');start=row
                identities.add((int(row['rootPid']),int(row['rootStartTicks'])))
                observers.append((int(row['observerPid']),path))
            entries=row.get('processes',[]) if row.get('kind')=='sample' else [row] if row.get('kind')=='seen' else []
            for entry in entries:identities.add((int(entry['pid']),int(entry['startTicks'])))
    require(start is not None and last is not None,'empty observer evidence')
    require(last.get('kind')=='end' and last.get('reason')=='owned-tree-ended' and last.get('remainingPids')==[],'owned observer tree did not end')
    return {'end':'owned-tree-ended','remainingPids':[],'recordsStreamed':records,'seconds':last['elapsed']}

def main():
    root=AREA/'mcpp'
    # This is the first artifact read: refuse while any stage is still running/incomplete.
    completed=read(root/'completed.json')
    require(list(completed['results'])==SEQUENCE,'all four actual stages must have ended in order before analysis')
    for stage in SEQUENCE:require((root/stage/'exit.json').is_file(),'missing terminal stage: '+stage)
    output=AREA/'terminal-analysis.json';require(not output.exists(),'never overwrite terminal analysis')
    require(sha(AREA/'diagnostic-plan.json')==PLAN_SHA,'registered plan changed')
    plan=read(AREA/'diagnostic-plan.json');dependency=plan['runnerDependency']
    binaries={'mcppls':SERVER_SHA,'mcppls-conformance':RUNNER_SHA}
    require(plan['source']==SOURCE and plan['profile']=='release' and plan['binaries']==binaries,'source/profile/binary envelope differs')
    require(plan['scriptSHA256']==RUN_SHA and sha(AREA/'run.py')==RUN_SHA,'orchestration script changed')
    require(plan['sequence']==SEQUENCE and plan['cacheLineage']==['a','a','a','b'] and plan['timeoutSeconds']==900,'original sequence/cache/timeout differs')
    require(plan['warmObserveSeconds']==300 and plan['warmReadySeconds']==12 and plan['producer']=='2026.9.30.2','original timing/producer differs')
    metadata=read(pathlib.Path(plan['releaseMetadata']))
    require(sha(pathlib.Path(plan['releaseMetadata']))==plan['releaseMetadataSHA256'],'product metadata changed')
    require(metadata['source']==SOURCE and metadata['profile']=='release' and metadata['binaries']['mcppls']['sha256']==SERVER_SHA,'product metadata mismatch')
    server=pathlib.Path(plan['frozenBin'])/'mcppls';runner=pathlib.Path(dependency['path'])
    require(dependency['ready'] and dependency['sha256']==RUNNER_SHA and sha(server)==SERVER_SHA and sha(runner)==RUNNER_SHA,'actual frozen binary SHA mismatch')
    provenance=dependency['provenance']
    require(provenance['kind']=='dirty-patch' and sha(pathlib.Path(provenance['patchPath']))==provenance['patchSha256'],'diagnostic runner patch changed')
    observer=plan['observer'];require(observer['cpu']=='9' and observer['pollSeconds']==1 and observer['sha256']==OBSERVER_SHA and sha(pathlib.Path(observer['script']))==OBSERVER_SHA,'observer registration changed')
    fixture=plan['allOriginalThresholdsAndInputs']['mcpp'];scenario=fixture['completeOriginalScenario']
    require(sha(pathlib.Path(fixture['path']))==fixture['sha256'] and read(pathlib.Path(fixture['path']))==scenario,'fixture changed')
    require(scenario['prepare'][1][-1]=='d1f1c98fa26d953e084a183a9672fc1e0ce63558','original pin differs')
    producer=read(root/'producer-preflight.json')
    require(producer['prefix']==plan['producerEnvironment']['prefix'] and '2026.9.30.2' in producer['version'] and producer['XLINGS_NON_INTERACTIVE']=='1','producer preflight differs')
    marker=read(root/'started.json')
    require(marker['source']==SOURCE and marker['profile']=='release' and marker['binaries']==binaries and marker['sequence']==SEQUENCE and marker['diagnosticRunnerProvenance']==provenance,'actual start envelope differs')
    identities=set();observers=[];stages=[];failed=0;total=0
    for stage in SEQUENCE:
        folder=root/stage;exit_data=read(folder/'exit.json')
        require(exit_data==completed['results'][stage],'completion/exit mismatch')
        invocation=read(folder/'invocation.json')
        expected=['taskset','-c','4-5',str(runner),'run','--server',str(server),'--payload',plan['payload'],'--fixture',str(pathlib.Path(fixture['path']).parent),
                  '--workspace-dir',str(root/'workspace'),'--cache-dir',str(root/('cache-b' if stage=='faults' else 'cache-a')),
                  '--stage',stage,'--timeout','900','--measure',str(folder/'measure.json'),'--verbose']
        if stage in ('warm','edits'):expected.append('--expect-warm')
        require(invocation['args']==expected and invocation['productServerSource']==SOURCE and invocation['diagnosticRunnerProvenance']==provenance,'stage args/provenance differ')
        require(read(folder/'binaries.json')==binaries,'stage binary SHA mismatch')
        observed=observer_evidence(folder/'processes.jsonl',identities,observers)
        archive=read(folder/'server-log-archive.json');require(archive['copiedAfterObservedTreeEnd'] is True,'logs were not archived after tree end')
        document=read(folder/'measure.json');checks=document['checks'];require(isinstance(checks,list) and checks,'missing actual checks')
        canonical=read(AREA.parent/'light-observer-final-acceptance-f6ec554'/'mcpp'/stage/'measure.json')
        signature=[(check['id'],check['kind']) for check in checks]
        require(signature==[(check['id'],check['kind']) for check in canonical['checks']],'original complete check signature differs')
        require(not any(check.get('detail','').startswith('skipped:') for check in checks),'original check skipped')
        failures=sum(check['ok'] is not True for check in checks)
        require(document['failures']==failures,'document/check failure counts differ')
        require((exit_data['exit']==0)==(failures==0),'process exit/check outcome disagree')
        total+=len(checks);failed+=failures
        record={'stage':stage,'exit':exit_data['exit'],'wallSecondsIncludingPrepareAndArchive':exit_data['wallSeconds'],'checks':len(checks),'failedChecks':failures,
                'checksActual':[{'id':check['id'],'kind':check['kind'],'ok':check['ok'],'detail':check.get('detail'),'failures':check.get('measure',{}).get('failures')} for check in checks],
                'originalCheckSignatureVerified':True,'observer':observed,'retainedLogFiles':len(archive['files']),
                'typing':{},'timeline':[]}
        for check in checks:
            measure=check.get('measure',{})
            if check['kind']=='timeline':record['timeline'].append({'id':check['id'],**trace_evidence(measure)})
            if check['id'] in ('U5-typing','U6-typing-autosave'):
                record['typing'][check['id']]={'ok':check['ok'],'requests':completion_evidence(measure),'server':server_evidence(measure)}
        stages.append(record)
    require(total==25,'four original stages must contain25 actual checks')
    live=[]
    for pid,birth in identities:
        try:
            raw=(pathlib.Path('/proc')/str(pid)/'stat').read_text();fields=raw[raw.rfind(')')+2:].split()
            if int(fields[19])==birth and fields[0]!='Z':live.append(pid)
        except FileNotFoundError:pass
    require(not live,'observed owned PID birth identities still live')
    for pid,path in observers:
        try:require(str(path) not in (pathlib.Path('/proc')/str(pid)/'cmdline').read_bytes().decode(errors='replace'),'observer still live')
        except FileNotFoundError:pass
    outcome='PASS' if all(item['exit']==0 for item in stages) and failed==0 else 'FAIL'
    require(completed['overall']==outcome,'overall outcome differs from actual checks/exits')
    summary={'createdEpoch':time.time(),'diagnosticOnly':True,'notNineStageAcceptance':True,'outcome':outcome,'allFourActualStagesTerminal':True,
             'source':SOURCE,'profile':'release','binaries':binaries,'runnerProvenance':provenance,'planSHA256':PLAN_SHA,'runSHA256':RUN_SHA,'helperSHA256':sha(pathlib.Path(__file__)),
             'fixtureSHA256':fixture['sha256'],'pin':scenario['prepare'][1][-1],'producer':producer,'workloadCPU':'4-5','observer':observer,
             'checks':total,'failedChecks':failed,'stages':stages,'observedPIDBirthIdentities':len(identities),'observedLiveRemaining':live,
             'boundaries':['All results preserved, including failure; no new attempts or gate changes.',
                           'One-second observer polling misses transient processes; observed ended tree is not every actual PID.',
                           'Helper reads completed JSON, bounded timing evidence and observer JSONL only; no raw server logs or PCM.',
                           'No PASS is treated as a repair or causal explanation; original nightly U5/U6 failure remains UNASSIGNED.'],
             'originalFailure':plan['originalNightlyFailure']}
    with output.open('x') as stream:stream.write(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({'output':str(output),'outcome':outcome,'stages':4,'checks':total,'failedChecks':failed}))

if __name__=='__main__':main()
